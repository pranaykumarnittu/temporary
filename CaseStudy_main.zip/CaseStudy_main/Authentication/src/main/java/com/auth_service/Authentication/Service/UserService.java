package com.auth_service.Authentication.Service;

import com.auth_service.Authentication.Controller.LoginRequest;
import com.auth_service.Authentication.Entity.Role;
import com.auth_service.Authentication.Entity.UserEntity;
import com.auth_service.Authentication.Repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RestTemplate restTemplate; // For calling course-service

    // Register a new user
    public ResponseEntity<String> register(UserEntity user) {
        if (userRepository.existsByUsername(user.getUsername())) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Username already exists");
        }
//        user.setPassword(passwordEncoder.encode(user.getPassword()));
        user.setApproved(false); // Requires admin approval
        userRepository.save(user);
        return ResponseEntity.ok("User registered, awaiting admin approval");
    }

    // Login user
    public ResponseEntity<UserEntity> login(LoginRequest request) {
        UserEntity user = userRepository.findByUsername(request.getUsername())
                .orElse(null);
        if (user == null || !(request.getPassword().equals(user.getPassword())) || !user.isApproved()) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(null);
        }
        return ResponseEntity.ok(user); // Return user details (in production, return JWT)
    }

    // Admin: Approve a user
    public ResponseEntity<String> approveUser(Long id, String adminUsername) {
        if (!isAdmin(adminUsername)) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Admin access required");
        }
        UserEntity user = userRepository.findById(id)
                .orElse(null);
        if (user == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User not found");
        }
        user.setApproved(true);
        userRepository.save(user);
        return ResponseEntity.ok("User approved");
    }

    // Admin: Remove a user
    public ResponseEntity<String> removeUser(Long id,String adminUsername) {
        if (!isAdmin(adminUsername)) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Admin access required");
        }
        if (!userRepository.existsById(id)) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User not found");
        }
        userRepository.deleteById(id);
        return ResponseEntity.ok("User removed");
    }

    // Admin: Approve a course (calls course-service)
    public ResponseEntity<String> approveCourse(Long courseId,String adminUsername) {
        if (!isAdmin(adminUsername)) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Admin access required");
        }
        String courseServiceUrl = "http://course-service/api/course/approve/" + courseId;
        ResponseEntity<String> response = restTemplate.postForEntity(courseServiceUrl, null, String.class);
        return ResponseEntity.status(response.getStatusCode()).body(response.getBody());
    }

    // Admin: Remove a course (calls course-service)
    public ResponseEntity<String> removeCourse(Long courseId,String adminUsername) {
        if (!isAdmin(adminUsername)) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Admin access required");
        }
        String courseServiceUrl = "http://course-service/api/course/" + courseId;
        restTemplate.delete(courseServiceUrl);
        return ResponseEntity.ok("Course removed");
    }

    // Helper method to check admin role
    private boolean isAdmin(String username) {
        UserEntity user = userRepository.findByUsername(username).orElse(null);
        return user != null && user.getRole() == Role.ADMIN;
    }

    // Helper method to check instructor role
    private boolean isInstructor(String username) {
        UserEntity user = userRepository.findByUsername(username).orElse(null);
        return user != null && user.getRole() == Role.INSTRUCTOR;
    }
}
