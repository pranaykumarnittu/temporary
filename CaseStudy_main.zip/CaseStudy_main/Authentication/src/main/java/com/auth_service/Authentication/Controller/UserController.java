package com.auth_service.Authentication.Controller;

import com.auth_service.Authentication.Entity.UserEntity;
import com.auth_service.Authentication.Repository.UserRepository;
import com.auth_service.Authentication.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;
import org.mindrot.jbcrypt.BCrypt;
import com.auth_service.Authentication.Entity.Role;

@RestController
@RequestMapping("/api/auth")
public class UserController {

    @Autowired
    private UserService service;

    @Autowired
    private RestTemplate restTemplate; // For calling course-service

    // Register a new user
    @PostMapping("/register")
    public ResponseEntity<String> register(@RequestBody UserEntity user) {
        return service.register(user);
    }

    // Login user
    @PostMapping("/login")
    public ResponseEntity<UserEntity> login(@RequestBody LoginRequest request) {
        return service.login(request);
    }

    // Admin: Approve a user
    @PostMapping("/approve/user/{id}")
    public ResponseEntity<String> approveUser(@PathVariable Long id, @RequestParam String adminUsername) {
        return service.approveUser(id, adminUsername);
    }

    // Admin: Remove a user
    @DeleteMapping("/user/{id}")
    public ResponseEntity<String> removeUser(@PathVariable Long id, @RequestParam String adminUsername) {
        return service.removeUser(id,adminUsername);
    }

    // Admin: Approve a course (calls course-service)
    @PostMapping("/approve/course/{courseId}")
    public ResponseEntity<String> approveCourse(@PathVariable Long courseId, @RequestParam String adminUsername) {
        return service.approveCourse(courseId,adminUsername);
    }

    // Admin: Remove a course (calls course-service)
    @DeleteMapping("/course/{courseId}")
    public ResponseEntity<String> removeCourse(@PathVariable Long courseId, @RequestParam String adminUsername) {
        return service.removeCourse(courseId,adminUsername);
    }
}


