package com.auth_service.Course.Controller;

import com.auth_service.Course.Entity.CourseEntity;
import com.auth_service.Course.Entity.EnrollmentEntity;
import com.auth_service.Course.Service.CourseResponse;
import com.auth_service.Course.Service.CourseService;
import com.auth_service.Course.Service.EnrollmentResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/course")
public class CourseController {

    @Autowired
    private CourseService courseService;

    // Instructor: Add a course
    @PostMapping
    public ResponseEntity<String> addCourse(@RequestBody CourseEntity course, @RequestParam Long instructorId) {
        return courseService.addCourse(course, instructorId);
    }

    // Instructor: Edit a course
    @PutMapping("/{courseId}")
    public ResponseEntity<String> editCourse(@PathVariable Long courseId, @RequestBody CourseEntity course,
                                             @RequestParam Long instructorId) {
        return courseService.editCourse(courseId, course, instructorId);
    }

    // Instructor: Delete a course
    @DeleteMapping("/{courseId}")
    public ResponseEntity<String> deleteCourse(@PathVariable Long courseId, @RequestParam Long instructorId) {
        return courseService.deleteCourse(courseId, instructorId);
    }

    // Admin: Approve a course
    @PostMapping("/approve/{courseId}")
    public ResponseEntity<String> approveCourse(@PathVariable Long courseId, @RequestParam Long adminId) {
        return courseService.approveCourse(courseId, adminId);
    }

    // Admin: Remove a course
    @DeleteMapping("/admin/{courseId}")
    public ResponseEntity<String> removeCourse(@PathVariable Long courseId, @RequestParam Long adminId) {
        return courseService.removeCourse(courseId, adminId);
    }

    // Student: Enroll in a course
    @PostMapping("/enroll/{courseId}")
    public ResponseEntity<String> enroll(@PathVariable Long courseId, @RequestParam Long studentId) {
        return courseService.enroll(courseId, studentId);
    }

    // Student: View progress
    @GetMapping("/student/progress")
    public ResponseEntity<List<EnrollmentResponse>> getProgress(@RequestParam Long studentId) {
        return courseService.getProgress(studentId);
    }

    // Instructor: View enrollments
    @GetMapping("/{courseId}/enrollments")
    public ResponseEntity<List<EnrollmentResponse>> getEnrollments(@PathVariable Long courseId,
                                                                   @RequestParam Long instructorId) {
        return courseService.getEnrollments(courseId, instructorId);
    }

    // Instructor: Remove enrollment
    @DeleteMapping("/{courseId}/enrollment/{studentId}")
    public ResponseEntity<String> removeEnrollment(@PathVariable Long courseId, @PathVariable Long studentId,
                                                   @RequestParam Long instructorId) {
        return courseService.removeEnrollment(courseId, studentId, instructorId);
    }

    // Instructor: Provide feedback
    @PostMapping("/{courseId}/feedback/{studentId}")
    public ResponseEntity<String> provideFeedback(@PathVariable Long courseId, @PathVariable Long studentId,
                                                  @RequestParam String feedbackText, @RequestParam Long instructorId) {
        return courseService.provideFeedback(courseId, studentId, feedbackText, instructorId);
    }

    // For content-service
    @GetMapping("/{courseId}")
    public ResponseEntity<CourseResponse> getCourse(@PathVariable Long courseId) {
        return courseService.getCourse(courseId);
    }

    @GetMapping("/enrollment/{studentId}/{courseId}")
    public ResponseEntity<EnrollmentEntity> getEnrollment(@PathVariable Long studentId, @PathVariable Long courseId) {
        return courseService.getEnrollment(studentId, courseId);
    }

}