package com.auth_service.Course.Service;

import com.auth_service.Course.Entity.CourseEntity;
import com.auth_service.Course.Entity.EnrollmentEntity;
import com.auth_service.Course.Entity.FeedbackEntity;
import com.auth_service.Course.Repository.CourseRepository;
import com.auth_service.Course.Repository.EnrollmentRepository;
import com.auth_service.Course.Repository.FeedbackRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;

@Service
public class CourseService {

    @Autowired
    private CourseRepository courseRepository;

    @Autowired
    private EnrollmentRepository enrollmentRepository;

    @Autowired
    private FeedbackRepository feedbackRepository;

    @Autowired
    private RestTemplate restTemplate;

    // Validate user role via auth-service
    private boolean isRole(Long userId, String role) {
        String authServiceUrl = "http://localhost:8081/api/auth/user/" + userId;
        ResponseEntity<UserResponse> response = restTemplate.getForEntity(authServiceUrl, UserResponse.class);
        return response.getStatusCode() == HttpStatus.OK && response.getBody() != null &&
                response.getBody().getRole().equalsIgnoreCase(role) && response.getBody().isApproved();
    }

    // Instructor: Add a course
    public ResponseEntity<String> addCourse(CourseEntity course, Long instructorId) {
        if (!isRole(instructorId, "INSTRUCTOR")) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Instructor access required");
        }
        course.setInstructorId(instructorId);
        course.setApproved(false);
        courseRepository.save(course);
        return ResponseEntity.ok("Course added, awaiting admin approval");
    }

    // Instructor: Edit a course
    public ResponseEntity<String> editCourse(Long courseId, CourseEntity updatedCourse, Long instructorId) {
        if (!isRole(instructorId, "INSTRUCTOR")) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Instructor access required");
        }
        CourseEntity course = courseRepository.findById(courseId).orElse(null);
        if (course == null || !course.getInstructorId().equals(instructorId)) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Course not found or unauthorized");
        }
        course.setTitle(updatedCourse.getTitle());
        course.setPrice(updatedCourse.getPrice());
        course.setApproved(false);
        courseRepository.save(course);
        return ResponseEntity.ok("Course updated, awaiting admin approval");
    }

    // Instructor: Delete a course
    public ResponseEntity<String> deleteCourse(Long courseId, Long instructorId) {
        if (!isRole(instructorId, "INSTRUCTOR")) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Instructor access required");
        }
        CourseEntity course = courseRepository.findById(courseId).orElse(null);
        if (course == null || !course.getInstructorId().equals(instructorId)) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Course not found or unauthorized");
        }
        courseRepository.delete(course);
        return ResponseEntity.ok("Course deleted");
    }

    // Admin: Approve a course
    public ResponseEntity<String> approveCourse(Long courseId, Long adminId) {
        if (!isRole(adminId, "ADMIN")) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Admin access required");
        }
        CourseEntity course = courseRepository.findById(courseId).orElse(null);
        if (course == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Course not found");
        }
        course.setApproved(true);
        courseRepository.save(course);
        return ResponseEntity.ok("Course approved");
    }

    // Admin: Remove a course
    public ResponseEntity<String> removeCourse(Long courseId, Long adminId) {
        if (!isRole(adminId, "ADMIN")) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Admin access required");
        }
        if (!courseRepository.existsById(courseId)) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Course not found");
        }
        courseRepository.deleteById(courseId);
        return ResponseEntity.ok("Course removed");
    }

    // Student: Enroll in a course
    public ResponseEntity<String> enroll(Long courseId, Long studentId) {
        String enrollmentServiceUrl = "http://localhost:8085/api/enrollment/enroll/" + courseId + "?studentId=" + studentId;
        ResponseEntity<String> response = restTemplate.postForEntity(enrollmentServiceUrl, null, String.class);
        return ResponseEntity.status(response.getStatusCode()).body(response.getBody());
    }

    // Student: View progress
    public ResponseEntity<List<EnrollmentResponse>> getProgress(Long studentId) {
        String enrollmentServiceUrl = "http://localhost:8085/api/enrollment/student/progress?studentId=" + studentId;
        ResponseEntity<EnrollmentResponse[]> response = restTemplate.getForEntity(enrollmentServiceUrl, EnrollmentResponse[].class);
        return ResponseEntity.status(response.getStatusCode()).body(List.of(response.getBody()));
    }

    // Instructor: View enrollments
    public ResponseEntity<List<EnrollmentResponse>> getEnrollments(Long courseId, Long instructorId) {
        String enrollmentServiceUrl = "http://localhost:8085/api/enrollment/course/" + courseId + "?instructorId=" + instructorId;
        ResponseEntity<EnrollmentResponse[]> response = restTemplate.getForEntity(enrollmentServiceUrl, EnrollmentResponse[].class);
        return ResponseEntity.status(response.getStatusCode()).body(List.of(response.getBody()));
    }

    // Instructor: Remove enrollment
    public ResponseEntity<String> removeEnrollment(Long courseId, Long studentId, Long instructorId) {
        String enrollmentServiceUrl = "http://localhost:8085/api/enrollment/course/" + courseId + "/student/" + studentId + "?userId=" + instructorId;
        restTemplate.delete(enrollmentServiceUrl);
        return ResponseEntity.ok("Enrollment removed");
    }


    // Instructor: Provide feedback
    public ResponseEntity<String> provideFeedback(Long courseId, Long studentId, String feedbackText, Long instructorId) {
        if (!isRole(instructorId, "INSTRUCTOR")) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Instructor access required");
        }
        CourseEntity course = courseRepository.findById(courseId).orElse(null);
        if (course == null || !course.getInstructorId().equals(instructorId)) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Course not found or unauthorized");
        }
        if (!enrollmentRepository.findByStudentIdAndCourseId(studentId, courseId).isPresent()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Student not enrolled");
        }
        FeedbackEntity feedback = new FeedbackEntity();
        feedback.setStudentId(studentId);
        feedback.setCourseId(courseId);
        feedback.setFeedbackText(feedbackText);
        feedbackRepository.save(feedback);
        return ResponseEntity.ok("Feedback provided");
    }

    public ResponseEntity<CourseResponse> getCourse(Long courseId) {
        CourseEntity course = courseRepository.findById(courseId).orElse(null);
        if (course == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }
        CourseResponse response = new CourseResponse();
        response.setId(course.getId());
        response.setInstructorId(course.getInstructorId());
        response.setApproved(course.isApproved());
        return ResponseEntity.ok(response);
    }

    public ResponseEntity<EnrollmentEntity> getEnrollment(Long studentId, Long courseId) {
        EnrollmentEntity enrollment = enrollmentRepository.findByStudentIdAndCourseId(studentId, courseId).orElse(null);
        if (enrollment == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }
        return ResponseEntity.ok(enrollment);
    }

}

