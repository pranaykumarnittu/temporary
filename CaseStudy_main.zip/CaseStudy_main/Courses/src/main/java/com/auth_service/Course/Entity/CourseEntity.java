package com.auth_service.Course.Entity;

import jakarta.persistence.*;

@Entity
@Table(name = "course_entity")
public class CourseEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String title;

    private double price;

    private Long instructorId;

    private boolean isApproved = false; // Admin approval status

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public Long getInstructorId() {
        return instructorId;
    }

    public void setInstructorId(Long instructorId) {
        this.instructorId = instructorId;
    }

    public boolean isApproved() {
        return isApproved;
    }

    public void setApproved(boolean approved) {
        isApproved = approved;
    }

    public CourseEntity(){
    }

    public CourseEntity(Long id, String title, double price, Long instructorId, boolean isApproved) {
        this.id = id;
        this.title = title;
        this.price = price;
        this.instructorId = instructorId;
        this.isApproved = isApproved;
    }

    @Override
    public String toString() {
        return "CourseEntity{" +
                "id=" + id +
                ", title='" + title + '\'' +
                ", price=" + price +
                ", instructorId=" + instructorId +
                ", isApproved=" + isApproved +
                '}';
    }
}