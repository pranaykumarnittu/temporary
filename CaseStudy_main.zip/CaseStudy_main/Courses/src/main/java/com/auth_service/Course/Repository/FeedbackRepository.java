package com.auth_service.Course.Repository;

import com.auth_service.Course.Entity.FeedbackEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface FeedbackRepository extends JpaRepository<FeedbackEntity, Long> {
    List<FeedbackEntity> findByStudentIdAndCourseId(Long studentId, Long courseId);
}