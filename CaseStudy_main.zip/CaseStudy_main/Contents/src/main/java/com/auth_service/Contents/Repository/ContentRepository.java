package com.auth_service.Contents.Repository;

import com.auth_service.Contents.Entity.ContentEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ContentRepository extends JpaRepository<ContentEntity, Long> {
    List<ContentEntity> findByCourseId(Long courseId);
}