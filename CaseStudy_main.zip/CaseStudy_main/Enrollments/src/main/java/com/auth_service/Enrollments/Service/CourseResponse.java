package com.auth_service.Enrollments.Service;

class CourseResponse {
    private Long id;
    private Long instructorId;
    private boolean isApproved;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public Long getInstructorId() { return instructorId; }
    public void setInstructorId(Long instructorId) { this.instructorId = instructorId; }
    public boolean isApproved() { return isApproved; }
    public void setApproved(boolean approved) { isApproved = approved; }
}
