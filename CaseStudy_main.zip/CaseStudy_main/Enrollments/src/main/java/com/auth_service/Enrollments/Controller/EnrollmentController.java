package com.auth_service.Enrollments.Controller;

import com.auth_service.Enrollments.Entity.EnrollmentEntity;
import com.auth_service.Enrollments.Service.EnrollmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/enrollment")
public class EnrollmentController {

    @Autowired
    private EnrollmentService enrollmentService;

    // Student: Enroll in a course
    @PostMapping("/enroll/{courseId}")
    public ResponseEntity<String> enroll(@PathVariable Long courseId, @RequestParam Long studentId) {
        return enrollmentService.enroll(courseId, studentId);
    }

    // Student: View progress
    @GetMapping("/student/progress")
    public ResponseEntity<List<EnrollmentEntity>> getProgress(@RequestParam Long studentId) {
        return enrollmentService.getProgress(studentId);
    }

    // Instructor: View enrollments for a course
    @GetMapping("/course/{courseId}")
    public ResponseEntity<List<EnrollmentEntity>> getEnrollments(@PathVariable Long courseId, @RequestParam Long instructorId) {
        return enrollmentService.getEnrollments(courseId, instructorId);
    }

    // Instructor/Admin: Remove enrollment
    @DeleteMapping("/course/{courseId}/student/{studentId}")
    public ResponseEntity<String> removeEnrollment(@PathVariable Long courseId, @PathVariable Long studentId,
                                                   @RequestParam Long userId) {
        return enrollmentService.removeEnrollment(courseId, studentId, userId);
    }

    // Admin: View all enrollments
    @GetMapping("/all")
    public ResponseEntity<List<EnrollmentEntity>> getAllEnrollments(@RequestParam Long adminId) {
        return enrollmentService.getAllEnrollments(adminId);
    }

    // Check enrollment status (for content-service)
    @GetMapping("/{studentId}/{courseId}")
    public ResponseEntity<EnrollmentEntity> getEnrollment(@PathVariable Long studentId, @PathVariable Long courseId) {
        return enrollmentService.getEnrollment(studentId, courseId);
    }
}
