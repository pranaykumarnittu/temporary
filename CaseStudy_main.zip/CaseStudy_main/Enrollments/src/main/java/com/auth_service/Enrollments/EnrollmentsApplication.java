package com.auth_service.Enrollments;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EnrollmentsApplication {

	public static void main(String[] args) {
		SpringApplication.run(EnrollmentsApplication.class, args);
	}

}
