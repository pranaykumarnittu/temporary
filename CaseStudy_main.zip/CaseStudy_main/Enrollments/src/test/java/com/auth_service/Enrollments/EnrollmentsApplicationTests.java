package com.auth_service.Enrollments;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EnrollmentsApplicationTests {

	@Test
	void contextLoads() {
	}

}
