package com.auth_service.Course.Service;

public class EnrollmentResponse {
    private Long id;
    private Long studentId;
    private Long courseId;
    private double progress;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public Long getStudentId() { return studentId; }
    public void setStudentId(Long studentId) { this.studentId = studentId; }
    public Long getCourseId() { return courseId; }
    public void setCourseId(Long courseId) { this.courseId = courseId; }
    public double getProgress() { return progress; }
    public void setProgress(double progress) { this.progress = progress; }
}