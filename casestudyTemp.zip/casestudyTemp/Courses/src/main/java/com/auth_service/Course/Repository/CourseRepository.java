package com.auth_service.Course.Repository;

import com.auth_service.Course.Entity.CourseEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CourseRepository extends JpaRepository<CourseEntity, Long> {
    List<CourseEntity> findByInstructorId(Long instructorId);
}