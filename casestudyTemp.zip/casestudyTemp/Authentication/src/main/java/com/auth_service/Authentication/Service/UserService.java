package com.auth_service.Authentication.Service;

import com.auth_service.Authentication.Controller.LoginRequest;
import com.auth_service.Authentication.Entity.UserEntity;
import com.auth_service.Authentication.Repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RestTemplate restTemplate; // For calling course-service

    // Register a new user
    public ResponseEntity<String> register(UserEntity user) {
        if (userRepository.existsByUsername(user.getUsername())) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Username already exists");
        }
//        user.setPassword(passwordEncoder.encode(user.getPassword()));
        userRepository.save(user);
        return ResponseEntity.ok("User registered Successfully");
    }

    // Login user
    public ResponseEntity<String> login(LoginRequest request) {
        UserEntity user = userRepository.findByUsername(request.getUsername())
                .orElse(null);
        if (user == null || !(request.getPassword().equals(user.getPassword()))) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(null);
        }
        return ResponseEntity.ok("Logged in as " + user.getRole()); // Return user details (in production, return JWT)
    }
}
