package com.auth_service.Authentication.Controller;

import com.auth_service.Authentication.Entity.UserEntity;
import com.auth_service.Authentication.Repository.UserRepository;
import com.auth_service.Authentication.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;
import org.mindrot.jbcrypt.BCrypt;
import com.auth_service.Authentication.Entity.Role;

@RestController
@RequestMapping("/api/auth")
public class UserController {

    @Autowired
    private UserService service;

    @Autowired
    private RestTemplate restTemplate; // For calling course-service

    // Register a new user
    @PostMapping("/register")
    public ResponseEntity<String> register(@RequestBody UserEntity user) {
        return service.register(user);
    }

    // Login user
    @PostMapping("/login")
    public ResponseEntity<String> login(@RequestBody LoginRequest request) {
        return service.login(request);
    }
}


