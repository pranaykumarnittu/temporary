package com.auth_service.Authentication.Entity;

public enum Role {
    ADMIN, INSTRUCTOR, STUDENT
}