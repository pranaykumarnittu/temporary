import { useForm } from 'react-hook-form';
import axios from 'axios';
import { useState } from 'react';
import { Form, Button, Alert, Card } from 'react-bootstrap';

function Login() {
    const {
        register,
        handleSubmit,
        formState: { errors },
    } = useForm();
    const [message, setMessage] = useState(null);
    const [error, setError] = useState(null);

    const onSubmit = async (data) => {
        try {
            const response = await axios.post('http://localhost:8080/api/auth/login', {
                username: data.username,
                password: data.password,
            });
            setMessage(response.data);
            setError(null);
        } catch (err) {
            setError('Invalid username or password');
            setMessage(null);
        }
    };

    return (
        <div className="d-flex justify-content-center mt-5">
            <Card style={{ width: '400px' }}>
                <Card.Body>
                    <Card.Title className="text-center">Login</Card.Title>
                    {message && <Alert variant="success">{message}</Alert>}
                    {error && <Alert variant="danger">{error}</Alert>}
                    <Form onSubmit={handleSubmit(onSubmit)}>
                        <Form.Group className="mb-3" controlId="username">
                            <Form.Label>Username</Form.Label>
                            <Form.Control
                                type="text"
                                placeholder="Enter username"
                                {...register('username', {
                                    required: 'Username is required',
                                    minLength: {
                                        value: 3,
                                        message: 'Username must be at least 3 characters',
                                    },
                                })}
                                isInvalid={!!errors.username}
                            />
                            <Form.Control.Feedback type="invalid">
                                {errors.username?.message}
                            </Form.Control.Feedback>
                        </Form.Group>

                        <Form.Group className="mb-3" controlId="password">
                            <Form.Label>Password</Form.Label>
                            <Form.Control
                                type="password"
                                placeholder="Enter password"
                                {...register('password', {
                                    required: 'Password is required',
                                    minLength: {
                                        value: 6,
                                        message: 'Password must be at least 6 characters',
                                    },
                                })}
                                isInvalid={!!errors.password}
                            />
                            <Form.Control.Feedback type="invalid">
                                {errors.password?.message}
                            </Form.Control.Feedback>
                        </Form.Group>

                        <Button variant="primary" type="submit" className="w-100">
                            Login
                        </Button>
                    </Form>
                </Card.Body>
            </Card>
        </div>
    );
}

export default Login;