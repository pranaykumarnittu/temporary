package com.auth_service.Enrollments.Service;

class CourseResponse {
    private Long id;
    private Long instructorId;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public Long getInstructorId() { return instructorId; }
    public void setInstructorId(Long instructorId) { this.instructorId = instructorId; }
}
