package com.auth_service.Enrollments.Service;

import com.auth_service.Enrollments.Entity.EnrollmentEntity;
import com.auth_service.Enrollments.Repository.EnrollmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;

@Service
public class EnrollmentService {

    @Autowired
    private EnrollmentRepository enrollmentRepository;

    @Autowired
    private RestTemplate restTemplate;

    // Validate user role via auth-service
    private ResponseEntity<UserResponse> getUser(Long userId) {
        String authServiceUrl = "http://localhost:8081/api/auth/user/" + userId;
        return restTemplate.getForEntity(authServiceUrl, UserResponse.class);
    }

    // Validate course existence and instructor ownership
    private ResponseEntity<CourseResponse> getCourse(Long courseId) {
        String courseServiceUrl = "http://localhost:8082/api/course/" + courseId;
        return restTemplate.getForEntity(courseServiceUrl, CourseResponse.class);
    }

    // Student: Enroll in a course
    public ResponseEntity<String> enroll(Long courseId, Long studentId) {
        ResponseEntity<UserResponse> userResponse = getUser(studentId);
        if (userResponse.getStatusCode() != HttpStatus.OK || userResponse.getBody() == null || !userResponse.getBody().getRole().equals("STUDENT")) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Student access required");
        }

        ResponseEntity<CourseResponse> courseResponse = getCourse(courseId);
        if (courseResponse.getStatusCode() != HttpStatus.OK) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Course not found");
        }

        if (enrollmentRepository.findByStudentIdAndCourseId(studentId, courseId).isPresent()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Already enrolled");
        }

        EnrollmentEntity enrollment = new EnrollmentEntity();
        enrollment.setStudentId(studentId);
        enrollment.setCourseId(courseId);
        enrollmentRepository.save(enrollment);
        return ResponseEntity.ok("Enrolled successfully");
    }

    // Student: View progress
    public ResponseEntity<List<EnrollmentEntity>> getProgress(Long studentId) {
        ResponseEntity<UserResponse> userResponse = getUser(studentId);
        if (userResponse.getStatusCode() != HttpStatus.OK || userResponse.getBody() == null ||  !userResponse.getBody().getRole().equals("STUDENT")) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(null);
        }

        return ResponseEntity.ok(enrollmentRepository.findByStudentId(studentId));
    }

    // Instructor: View enrollments for a course
    public ResponseEntity<List<EnrollmentEntity>> getEnrollments(Long courseId, Long instructorId) {
        ResponseEntity<UserResponse> userResponse = getUser(instructorId);
        if (userResponse.getStatusCode() != HttpStatus.OK || userResponse.getBody() == null ||  !userResponse.getBody().getRole().equals("INSTRUCTOR")) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(null);
        }

        ResponseEntity<CourseResponse> courseResponse = getCourse(courseId);
        if (courseResponse.getStatusCode() != HttpStatus.OK || !courseResponse.getBody().getInstructorId().equals(instructorId)) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }

        return ResponseEntity.ok(enrollmentRepository.findByCourseId(courseId));
    }

    // Check enrollment status (for content-service)
    public ResponseEntity<EnrollmentEntity> getEnrollment(Long studentId, Long courseId) {
        EnrollmentEntity enrollment = enrollmentRepository.findByStudentIdAndCourseId(studentId, courseId).orElse(null);
        if (enrollment == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }
        return ResponseEntity.ok(enrollment);
    }
}




