package com.auth_service.Contents;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ContentsApplicationTests {

	@Test
	void contextLoads() {
	}

}
