package com.auth_service.Contents.Repository;


import com.auth_service.Contents.Entity.EnrollmentEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface EnrollmentRepository extends JpaRepository<EnrollmentEntity, Long> {
    Optional<EnrollmentEntity> findByStudentIdAndCourseId(Long studentId, Long courseId);
    List<EnrollmentEntity> findByCourseId(Long courseId);
    List<EnrollmentEntity> findByStudentId(Long studentId);
}