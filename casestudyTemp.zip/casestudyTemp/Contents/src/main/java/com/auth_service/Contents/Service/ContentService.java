package com.auth_service.Contents.Service;

import com.auth_service.Contents.Entity.ContentEntity;
import com.auth_service.Contents.Entity.EnrollmentEntity;
import com.auth_service.Contents.Repository.ContentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;
import software.amazon.awssdk.auth.credentials.AwsBasicCredentials;
import software.amazon.awssdk.auth.credentials.StaticCredentialsProvider;
import software.amazon.awssdk.core.sync.RequestBody;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.PutObjectRequest;

import java.io.IOException;
import java.util.List;

@Service
public class ContentService {

    @Autowired
    private ContentRepository contentRepository;

    @Autowired
    private RestTemplate restTemplate;

    @Value("${aws.s3.bucket}")
    private String bucketName;

    @Value("${aws.accessKeyId}")
    private String accessKeyId;

    @Value("${aws.secretAccessKey}")
    private String secretAccessKey;

    @Value("${aws.region}")
    private String region;

    // Validate user role via auth-service
    private ResponseEntity<UserResponse> getUser(Long userId) {
        String authServiceUrl = "http://localhost:8081/api/auth/user/" + userId;
        return restTemplate.getForEntity(authServiceUrl, UserResponse.class);
    }

    // Validate course existence and instructor ownership
    private ResponseEntity<CourseResponse> getCourse(Long courseId) {
        String courseServiceUrl = "http://localhost:8082/api/course/" + courseId;
        return restTemplate.getForEntity(courseServiceUrl, CourseResponse.class);
    }

    // Check if student is enrolled
    private boolean isEnrolled(Long studentId, Long courseId) {
        String enrollmentServiceUrl = "http://localhost:8085/api/enrollment/" + studentId + "/" + courseId;
        ResponseEntity<EnrollmentResponse> response = restTemplate.getForEntity(enrollmentServiceUrl, EnrollmentResponse.class);
        return response.getStatusCode() == HttpStatus.OK && response.getBody() != null;
    }

    // Upload content to S3
    public ResponseEntity<String> uploadContent(Long courseId, String type, MultipartFile file, Long userId) {
        ResponseEntity<UserResponse> userResponse = getUser(userId);
        if (userResponse.getStatusCode() != HttpStatus.OK || userResponse.getBody() == null || !userResponse.getBody().isApproved()) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Invalid or unapproved user");
        }
        String role = userResponse.getBody().getRole();

        ResponseEntity<CourseResponse> courseResponse = getCourse(courseId);
        if (courseResponse.getStatusCode() != HttpStatus.OK || !courseResponse.getBody().isApproved()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Course not found or not approved");
        }

        if (role.equals("INSTRUCTOR") && !courseResponse.getBody().getInstructorId().equals(userId)) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Instructor not authorized for this course");
        } else if (!role.equals("ADMIN") && !role.equals("INSTRUCTOR")) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Admin or Instructor access required");
        }

        S3Client s3Client = S3Client.builder()
                .region(Region.of(region))
                .credentialsProvider(StaticCredentialsProvider.create(
                        AwsBasicCredentials.create(accessKeyId, secretAccessKey)))
                .build();

        String key = "course-" + courseId + "/" + file.getOriginalFilename();
        try {
            s3Client.putObject(PutObjectRequest.builder()
                            .bucket(bucketName)
                            .key(key)
                            .build(),
                    RequestBody.fromInputStream(file.getInputStream(), file.getSize()));

            ContentEntity content = new ContentEntity();
            content.setCourseId(courseId);
            content.setType(type);
            content.setUrl("https://" + bucketName + ".s3." + region + ".amazonaws.com/" + key);
            content.setFileName(file.getOriginalFilename());
            contentRepository.save(content);

            return ResponseEntity.ok("Content uploaded successfully");
        } catch (IOException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Upload failed: " + e.getMessage());
        }
    }

    // Get content for a course
    public ResponseEntity<List<ContentEntity>> getContent(Long courseId, Long userId) {
        ResponseEntity<UserResponse> userResponse = getUser(userId);
        if (userResponse.getStatusCode() != HttpStatus.OK || userResponse.getBody() == null || !userResponse.getBody().isApproved()) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(null);
        }
        String role = userResponse.getBody().getRole();

        ResponseEntity<CourseResponse> courseResponse = getCourse(courseId);
        if (courseResponse.getStatusCode() != HttpStatus.OK || !courseResponse.getBody().isApproved()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }

        if (role.equals("INSTRUCTOR") && !courseResponse.getBody().getInstructorId().equals(userId)) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(null);
        } else if (role.equals("STUDENT") && !isEnrolled(userId, courseId)) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(null);
        } else if (!role.equals("ADMIN") && !role.equals("INSTRUCTOR") && !role.equals("STUDENT")) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(null);
        }

        return ResponseEntity.ok(contentRepository.findByCourseId(courseId));
    }

    // Delete content
    public ResponseEntity<String> deleteContent(Long contentId, Long userId) {
        ResponseEntity<UserResponse> userResponse = getUser(userId);
        if (userResponse.getStatusCode() != HttpStatus.OK || userResponse.getBody() == null || !userResponse.getBody().isApproved()) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Invalid or unapproved user");
        }
        String role = userResponse.getBody().getRole();

        ContentEntity content = contentRepository.findById(contentId).orElse(null);
        if (content == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Content not found");
        }

        ResponseEntity<CourseResponse> courseResponse = getCourse(content.getCourseId());
        if (courseResponse.getStatusCode() != HttpStatus.OK) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Course not found");
        }

        if (role.equals("INSTRUCTOR") && !courseResponse.getBody().getInstructorId().equals(userId)) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Instructor not authorized");
        } else if (!role.equals("ADMIN") && !role.equals("INSTRUCTOR")) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Admin or Instructor access required");
        }

        S3Client s3Client = S3Client.builder()
                .region(Region.of(region))
                .credentialsProvider(StaticCredentialsProvider.create(
                        AwsBasicCredentials.create(accessKeyId, secretAccessKey)))
                .build();
        String key = "course-" + content.getCourseId() + "/" + content.getFileName();
        s3Client.deleteObject(b -> b.bucket(bucketName).key(key).build());

        contentRepository.delete(content);
        return ResponseEntity.ok("Content deleted successfully");
    }

}



