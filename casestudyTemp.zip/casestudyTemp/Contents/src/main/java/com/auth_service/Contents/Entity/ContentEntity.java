package com.auth_service.Contents.Entity;

import jakarta.persistence.*;

@Entity
@Table(name = "content_entity")
public class ContentEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long courseId;

    private String type; // e.g., VIDEO, DOCUMENT

    private String url; // S3 URL

    private String fileName; // Original file name

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getCourseId() {
        return courseId;
    }

    public void setCourseId(Long courseId) {
        this.courseId = courseId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public ContentEntity(){

    }

    public ContentEntity(Long id, Long courseId, String type, String url, String fileName) {
        this.id = id;
        this.courseId = courseId;
        this.type = type;
        this.url = url;
        this.fileName = fileName;
    }

    @Override
    public String toString() {
        return "ContentEntity{" +
                "id=" + id +
                ", courseId=" + courseId +
                ", type='" + type + '\'' +
                ", url='" + url + '\'' +
                ", fileName='" + fileName + '\'' +
                '}';
    }
}
