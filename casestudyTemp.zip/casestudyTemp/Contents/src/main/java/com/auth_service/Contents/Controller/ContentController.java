package com.auth_service.Contents.Controller;

import com.auth_service.Contents.Entity.ContentEntity;
import com.auth_service.Contents.Service.ContentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
@RequestMapping("/api/content")
public class ContentController {

    @Autowired
    private ContentService contentService;

    // Upload content
    @PostMapping("/upload")
    public ResponseEntity<String> uploadContent(@RequestParam Long courseId,
                                                @RequestParam String type,
                                                @RequestParam MultipartFile file,
                                                @RequestParam Long userId) {
        return contentService.uploadContent(courseId, type, file, userId);
    }

    // Get content for a course
    @GetMapping("/course/{courseId}")
    public ResponseEntity<List<ContentEntity>> getContent(@PathVariable Long courseId,
                                                          @RequestParam Long userId) {
        return contentService.getContent(courseId, userId);
    }

    // Delete content
    @DeleteMapping("/{contentId}")
    public ResponseEntity<String> deleteContent(@PathVariable Long contentId,
                                                @RequestParam Long userId) {
        return contentService.deleteContent(contentId, userId);
    }
}
